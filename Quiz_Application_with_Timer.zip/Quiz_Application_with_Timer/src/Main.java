import java.util.Scanner;

public class Main {
    public static void main(String[] args)  {


        Scanner input=new Scanner(System.in);
        System.out.println("\t\t  Quiz");
        System.out.println("\t\t----------");


        boolean isvalid= false;
        while(!isvalid) {
            System.out.println("\n\nEnter \"1\" to Start or \"0\" to Exit");
            System.out.print("Select an option : ");
            int option=input.nextInt();
            if (option == 1) {
                System.out.println();
                Quiz.question1();
                Quiz.question2();
                Quiz.question3();
                Quiz.question4();
                Quiz.question5();

                System.out.println("\n\nTotal Marks you got : " + Result.marks());
                Result.answers();

                isvalid=true;
            } else if(option==0) {
                System.out.println("Exit");
                isvalid=true;
            }
            else{
                System.out.println("Please Enter either 0 or 1");
            }
        }
    }
}