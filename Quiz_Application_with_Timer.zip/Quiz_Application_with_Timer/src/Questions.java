public class Questions {
    public static void question1(){
        System.out.println("\n1.What is the Capital of India");
        System.out.println("options:");
        System.out.println("1.Mumbai\n2.Hyderabad\n3.New Delhi\n4.Bangalore");
    }

    public static void question2(){
        System.out.println("\n\n2. How many continents are there on Earth");
        System.out.println("options:");
        System.out.println("1. 7\n2. 5\n3. 6\n4. 8");
    }

    public static void question3(){
        System.out.println("\n\n3. What is the chemical symbol for water");
        System.out.println("options:");
        System.out.println("1. O2\n2. CO2\n3. OH\n4. H20");
    }

    public static void question4(){
        System.out.println("\n\n4. Divide 143 with 0 => (143/0)");
        System.out.println("options:");
        System.out.println("1. 0\n2. Infinity\n3. 1\n4. No value");
    }

    public static void question5(){
        System.out.println("\n\n5. JVM stands for ");
        System.out.println("options:");
        System.out.println("1. Java vector Machine\n2. Java Virtual Model\n3. Java Virtual Machine\n4. Java visual Machine");
    }
}
