import java.io.IOException;
import java.util.Scanner;

public class Quiz {
    static int question1,question2,question3,question4,question5;
    static Scanner input=new Scanner(System.in);
    static int count=0;


    public static void question1() {
        Questions.question1();
        System.out.println("\nyou have 1 minute time to answer");
        boolean answer=false;

        long start = System.currentTimeMillis();
        System.out.print("\nSelect an option : ");
        while (System.currentTimeMillis() - start < 60000) {
            try {
                if (System.in.available() > 0) {
                    question1 = input.nextInt();
                    if(question1>=1 && question1<=4){
                        answer=true;
                        break;
                    }
                    else{
                        System.out.print("Select an options from the above(1,2,3,4) : ");
                    }

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if(answer) {
            if(question1==3){
                count++;
            }
        }
        else{
            System.out.println("\nTime is up!!!");
        }
    }


    public static void question2(){
        Questions.question2();
        System.out.println("\nyou have 1 minute time to answer");
        boolean answer=false;

        long start=System.currentTimeMillis();
        System.out.print("\nSelect an option : ");
        while(System.currentTimeMillis()-start<60000) {

            try {
                if (System.in.available() > 0) {
                    question2 = input.nextInt();
                    if (question2 >= 0 && question2 <= 4) {
                        answer = true;
                        break;
                    } else {
                        System.out.print("Select an options from the above (1,2,3,4) : ");
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(answer){
            if(question2==1){
                count++;
            }
        }
        else{
            System.out.println("\nTime is up!!!");
        }
    }


    public static void question3(){
        Questions.question3();
        System.out.println("\nyou have 1 minute time to answer");
        boolean answer=false;

        long start=System.currentTimeMillis();
        System.out.print("\nselect an option : ");
        while(System.currentTimeMillis()-start<60000){

            try{
                if(System.in.available()>0){
                    question3=input.nextInt();
                    if(question3>=0 && question3<=4){
                        answer=true;
                        break;
                    }
                    else {
                        System.out.print("Select an options from the above (1,2,3,4)");
                    }
                }
            }
            catch (IOException e){
                e.printStackTrace();
            }
        }
        if(answer){
            if(question3==4){
                count++;
            }
        }
        else {
            System.out.println("\nTime is up!!!");
        }
    }

    public static void question4(){
        Questions.question4();
        System.out.println("\nyou have one minute to answer");
        boolean answer=false;

        long start=System.currentTimeMillis();
        System.out.print("\nSelect an option : ");
        while (System.currentTimeMillis()-start<60000){

            try{
                if(System.in.available()>0){
                    question4=input.nextInt();
                    if(question4>=0 && question4<=4){
                        answer=true;
                        break;
                    }
                    else{
                        System.out.print("Select an options from the above (1,2,3,4) : ");
                    }
                }
            }
            catch (IOException e){
                e.printStackTrace();
            }
        }
        if(answer){
            if(question4==2){
                count++;
            }
        }
        else{
            System.out.println("\nTime is up!!!");
        }
    }

    public static void question5(){
        Questions.question5();
        System.out.println("\nyou have 1 minute time to answer");
        boolean answer=false;

        long start=System.currentTimeMillis();
        System.out.print("\nSelect an option : ");
        while (System.currentTimeMillis()-start<60000){

            try{
                if(System.in.available()>0){
                    question5=input.nextInt();
                    if(question5>=0 && question5<=4){
                        answer=true;
                        break;
                    }
                    else {
                        System.out.print("Select an option from the above (1,2,3,4) : ");
                    }
                }
            }
            catch (IOException e){
                e.printStackTrace();
            }
        }
        if(answer){
            if(question5==3){
                count++;
            }
        }
        else {
            System.out.println("\nTime is up!!!");
        }
    }
}


