public class Result {
    public static int marks(){
        return Quiz.count;
    }
    public static void answers(){
        System.out.println("\n----------------------------------------------------------------------------------");
        System.out.println("\n\nAnswers");

        Questions.question1();
        System.out.println("\nCorrect Option : 3");
        System.out.println("you selected : "+Quiz.question1);
        System.out.println("\n\n");

        Questions.question2();
        System.out.println("\nCorrect Option : 1");
        System.out.println("you selected : "+Quiz.question2);
        System.out.println("\n\n");

        Questions.question3();
        System.out.println("\nCorrect Option : 4");
        System.out.println("you selected : "+Quiz.question3);
        System.out.println("\n\n");

        Questions.question4();
        System.out.println("\nCorrect Option : 2");
        System.out.println("you selected : "+Quiz.question4);
        System.out.println("\n\n");

        Questions.question5();
        System.out.println("\nCorrect Option : 3");
        System.out.println("you selected : "+Quiz.question5);
        System.out.println("\n\n");
    }
}
